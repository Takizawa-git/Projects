#Gates for BitAdder

#AND Gate 
def AND_Gate(a,b):
    if a==1 and b==1:
        return 1
    else:
        return 0

#OR Gate
def OR_Gate(a,b):
    if a==0 and b==0:
        return 0
    else:
        return 1

#XOR Gate
def XOR_Gate(a,b):
    if (a==1 and b==1) or (a==0 and b==0):
        return 0
    else:
        return 1

    
