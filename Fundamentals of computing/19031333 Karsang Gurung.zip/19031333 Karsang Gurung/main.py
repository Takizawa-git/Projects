import conversion as bc #import functions from module conversion
import BitAdder as BAdder #import functions from module BitAdder

def BinaryAdder():
    print("WELCOME TO BIT ADDER APPLICATION")
    execute = False #Condition for the main loop to continue
    while execute == False:
        complete = False #condition for the input loop to continue
        while complete == False:
            try:
                x = int(input("Enter 1st Number: ")) #input integer value
               
                cin = 0
                if x > 255 or x < 0:
                    print("Please enter a number between 0 and 255")
                else:
                    complete = True
            except:
                print("The entered value is unacceptable.") #exception if the user inputs unsuitable characters
        complete = False
        while complete == False:
            try:
                y = int(input("Enter 2nd Number: "))
                if y > 255 or y<0:
                    print("Please enter a number between 0 and 255")
                else:
                    complete = True
            except:
                print("The entered value is unacceptable") #exception if the user inputs unsuitable characters
        BinaryX = bc.decimalToBinary(x) #binary value of x in string
        BinaryY = bc.decimalToBinary(y) #binary value of Y in string
        print(f"Binary Value of 1st number: {BinaryX}")
        print(f"Binary Value of 2nd Number: {BinaryY}")
        value = ""
        value = BAdder.byte_adder(str(BinaryX),str(BinaryY),cin) #adding two 8-digit binary numbers
        print(f"Sum: {value}")
        
        exe = input("Press Enter to Continue or Enter X to Exit: ") #asking if the user wants to continue
        exe = exe.upper() #changes inputs to uppercase
        if exe == "X":
            execute = True
            print("Thank you for using the application. Goodbye!")

            
BinaryAdder() #calling function Binary adder

