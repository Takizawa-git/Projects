import LogicalGates as gate #importing functions from LogicalGates

def byte_adder(a, b, cin):
    output = ""
    #sum value
    for i in range(len(b)-1,-1,-1): #loop 8 times 
        fs = gate.XOR_Gate(int(a[i]),int(b[i]))
        sum_var = gate. XOR_Gate(fs, cin)
        output += str(sum_var)
        #for carryOver
        fco = gate.AND_Gate(int(a[i]),int(b[i]))
        fco2 = gate.AND_Gate(fs,cin)
        Co = gate.OR_Gate(fco, fco2)
        cin = Co
        #carry over value
    if cin == 1:
        output += str(cin)
    output = output[::-1] #Reversing the output

    return output
